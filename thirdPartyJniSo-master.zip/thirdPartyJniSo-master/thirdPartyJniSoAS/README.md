Jni调用第三方的so库  android studio 示例
