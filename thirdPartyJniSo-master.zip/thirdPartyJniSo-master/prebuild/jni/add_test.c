int add_fun(int a, int b) {
	return a + b;
}
